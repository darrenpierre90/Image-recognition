--------------------
| - General Info - |
--------------------
MEMBERS
	- Tess Landry: 100926518
	- Darren Pierre: 101015833

FILES
	- report.pdf
	- code.zip
		- README.txt
		- COMP4900A3.ipynb
		- Copy_of_COMP4900A3.ipynb
		- Ensemble.ipynb

NOTES
	- Please hit all play buttons in order
	- Validation section is labeled if you would like to try validating (in "Copy of COMP4900A3.ipynb" file)
	- First two files were split into two for ease of running multiple models at once
		- Feel free to add models from one to another to test the validation, etc.
		

-------------
| - FILES - |
-------------

COMP4900A3.IPYNB
	- Contains code to run the MLP, AlexNet, and Transfer Learning

COPY_OF_COMP4900A3.IPYNB
	- Contains code to run the validation, LeNet, VGG-16

ENSEMBLE.IPYNB
	- Contains code to run an ensemble. Currently set up to run 6 files. Choose any 6 output files (.csv) and run them (adjust names of files accordingly). 

